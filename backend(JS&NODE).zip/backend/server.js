const express = require("express")
const cors = require("cors")

const userRoutes = require("./routes/users")
const professionalRoutes = require("./routes/professionals")
const sensorRoutes = require("./routes/sensors")

const app = express()

app.use(cors())
app.use(express.json())

app.use("/users", userRoutes)
app.use("/professionals", professionalRoutes)
app.use("/sensors", sensorRoutes)

app.get("/", (req, res) => {
    res.send("API Vital Experience funcionando")
})

const PORT = 3000

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`)
})
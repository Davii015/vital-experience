const express = require("express")
const router = express.Router()

const db = require("../data/database")

router.get("/", (req, res) => {
    res.json(db.users)
})

router.post("/", (req, res) => {

    const user = {
        id: Date.now(),
        name: req.body.name,
        age: req.body.age
    }

    db.users.push(user)

    res.json(user)
})

module.exports = router
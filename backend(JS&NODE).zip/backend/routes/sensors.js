const express = require("express")
const router = express.Router()

const db = require("../data/database")

router.get("/", (req, res) => {
    res.json(db.sensorData)
})

router.post("/", (req, res) => {

    const data = {
        id: Date.now(),
        userId: req.body.userId,
        heartRate: req.body.heartRate,
        movement: req.body.movement,
        timestamp: new Date()
    }

    db.sensorData.push(data)

    res.json(data)
})

module.exports = router
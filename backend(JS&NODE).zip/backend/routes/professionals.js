const express = require("express")
const router = express.Router()

const db = require("../data/database")

router.get("/", (req, res) => {
    res.json(db.professionals)
})

router.post("/", (req, res) => {

    const professional = {
        id: Date.now(),
        name: req.body.name,
        specialty: req.body.specialty
    }

    db.professionals.push(professional)

    res.json(professional)
})

module.exports = router
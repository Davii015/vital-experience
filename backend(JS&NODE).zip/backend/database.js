const users = []
const professionals = []
const sensorData = []

module.exports = {
    users,
    professionals,
    sensorData
}